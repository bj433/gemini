#include "kontoliste.h"

kontoliste::kontoliste()
{

}
