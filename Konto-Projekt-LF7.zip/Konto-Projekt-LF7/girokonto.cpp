#include "girokonto.h"

girokonto::girokonto()
{

}
