#include "sparkonto.h"

sparkonto::sparkonto()
{

}
